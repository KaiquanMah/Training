
from vertexai.preview.reasoning_engines import AdkApp

if False:
  from google.adk.agents import config_agent_utils
  try:
    # This path is for local loading.
    root_agent = config_agent_utils.from_config("/home/student_00_33df1dc70dfc/adk_to_agent_engine/transcript_summarization_agent/root_agent.yaml")
  except FileNotFoundError:
    # This path is used to support the file structure in Agent Engine.
    root_agent = config_agent_utils.from_config(".//tmp/agent_engine_deploy_src/20251130_070436/transcript_summarization_agent/root_agent.yaml")
else:
  from transcript_summarization_agent.agent import root_agent

adk_app = AdkApp(
  agent=root_agent,
  enable_tracing=False,
)
