
from vertexai.preview.reasoning_engines import AdkApp

if False:
  from google.adk.agents import config_agent_utils
  try:
    # This path is for local loading.
    root_agent = config_agent_utils.from_config("/home/student_01_fcaf8c44c469/adk_challenge_lab/paint_agent/root_agent.yaml")
  except FileNotFoundError:
    # This path is used to support the file structure in Agent Engine.
    root_agent = config_agent_utils.from_config(".//tmp/agent_engine_deploy_src/20251202_024100/paint_agent/root_agent.yaml")
else:
  from paint_agent.agent import root_agent

adk_app = AdkApp(
  agent=root_agent,
  enable_tracing=False,
)
