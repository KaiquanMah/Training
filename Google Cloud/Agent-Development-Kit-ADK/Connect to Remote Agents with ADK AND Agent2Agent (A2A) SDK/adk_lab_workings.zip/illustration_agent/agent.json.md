# Documentation for agent.json

This file provides context for the configuration in `agent.json`.

### `defaultInputModes`

-   **Comment:** `input = prompt`
-   **Details:** The agent expects a simple text prompt as its input.

### `defaultOutputModes`

-   **Comment:** `output is the URL of the generated img AND text of the input prompt`
-   **Details:** The agent returns a JSON object. Based on the agent's logic in `agent.py`, this will contain the **URL** of the generated image and the **prompt text** used to create it.